please do not take any thing from this website with out shouting out flyingman8877 and https://codepen.io/Adir-SL thank you 

thank you have a good day

if you have any questions add them in the coments