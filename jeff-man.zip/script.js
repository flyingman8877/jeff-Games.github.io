function validateForm() {
  let x = document.forms["myForm"]["fname"].value;
  if (x == "yesssssssssss") {
    
  }
  else{
    alert("you have fail");
    window.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  }
    
  